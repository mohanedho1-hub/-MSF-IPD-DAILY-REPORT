# MSF IPD DAILY REPORT — Android starter project

This is an Android Studio project using a local HTML report UI inside Android WebView. It includes case totals, admission/discharge and OT totals, on-device report history, PNG image export, print/PDF through Android's print dialog, and text sharing through Android's share sheet where supported.

## Build an APK
1. Open this folder in Android Studio (current stable version).
2. Allow Gradle sync and install any requested Android SDK platform (compile SDK 35).
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location.

## Important notes
- The project source has not been built or tested in this environment; a compiled APK is not included.
- Branding at present uses text placeholders, not official MSF or Palestinian Ministry of Health logo artwork. Insert approved logo assets only if authorized.
- Data is stored locally in WebView storage on this device; this starter has no cloud backup or multi-user sync.
